package space;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public abstract class Element {

    public double x, y;
    public int w, h;
    public double velx, vely;
    public BufferedImage img;
    public String caminho;

    public Element(double x, double y, int w, int h, double velx, double vely) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.velx = velx;
        this.vely = vely;
    }

    public void move() {
        x += velx;
        y += vely;

    }

    public void image() {

        try {
            img = ImageIO.read(new File(caminho));
        } catch (IOException ex) {
            Logger.getLogger(Element.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void paint(Graphics2D g2) {

        g2.drawImage(img, (int) x, (int) y, img.getWidth(), img.getHeight(), null);

    }

    public void update() {
        move();
    }

}
