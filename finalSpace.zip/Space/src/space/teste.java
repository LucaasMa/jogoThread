package space;

import java.util.List;
import java.util.ArrayList;

public class teste {

    public static void main(String[] args) {
        List<Double> lista = new ArrayList<>();// arraylist = vetor de tamanho variavel

        lista.add(5.8);
        lista.add(8.0);
        lista.add(7.0);
        lista.add(1.0);
        
        lista.removeIf(i -> i%2==0);
         //lista.removeIf(monstro -> != vivo);
        
        lista.remove(1.0);
        
        

        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i));
        }

        
    }

}
