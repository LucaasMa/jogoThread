package space;

public class Missile extends Element {

    static int h_ = 10;
    static int w_ = 5;
    boolean vivo;
    static double vely = -20; //negativo == sobe

    public Missile(double x, double y) {
        super(x, y, w_, h_, 0, vely);
        vivo = true;
        this.caminho = "src/space/imagens/aaa.jpg";
        super.image();
    }

    @Override
    public void move() {
        super.move();
        if (y < 0) {
            vivo = false;
        }
    }

}
