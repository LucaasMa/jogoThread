package space;

public class Alien extends Element {

    static int _wa = 50;
    static int _ha = 50;
    static int _velx = 3;
    static int _vely = 0;
    boolean alive;
    

    public Alien(double x, double y) {
        super(x, y, _wa, _ha, _velx, _vely);
        alive = true;
        this.caminho = "src/space/imagens/alienCerto.png";
        super.image();
        
    }

    public void colidir(Missile tiro) {
        if (tiro != null && tiro.vivo) {
            if (tiro.x > x && tiro.x < x + _wa && tiro.y > y && tiro.y < y + _ha) {
                tiro.vivo = false;
                this.alive = false;
                Universe.cont += 100;

            }

        }
    }

    @Override
    public void move() {
        super.move();

    }

    @Override
    public void update() {
        super.update();
    }

    public boolean bateParede() {
        return (x < 0 || x > 785 - _wa);

    }

    public void inverte() {

        velx *= -1;
    }

    public void pulay() {
        y += 19;
    }

}
