package space;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Universe extends JPanel implements Runnable {

    private static Universe singleton;
    List<List<Alien>> inimigos = new ArrayList();
    Ship ship;
    public static int cont = 0;
    public static int contador = 0;
    static JLabel label;
    public BufferedImage fundo;

    public List<List<Alien>> getInimigos() {
        return inimigos;
    }

    public static synchronized Universe getInstance() {//synchonized 
        if (singleton == null) {
            singleton = new Universe();

        }
        return singleton;
    }

    private Universe() {
        setBackground(Color.white);
        setLayout(new FlowLayout());
        setVisible(true);
        enemies();
        ship = Ship.getInstance(this);

    }

    public void backGround(Graphics2D g2) {

        try {
            fundo = ImageIO.read(new File("src/space/imagens/planodeFundo.PNG"));
        } catch (IOException ex) {
            Logger.getLogger(Universe.class.getName()).log(Level.SEVERE, null, ex);
        }
        g2.drawImage(fundo, 0, 0, fundo.getWidth(), fundo.getHeight(), null);
    }

    public void enemies() {
        for (int i = 0; i < 4; i++) {
            inimigos.add(new ArrayList<>());
            for (int j = 0; j < 10; j++) {
                inimigos.get(i).add(new Alien(50 * j + 50, 50 * i + 50));

            }

        }

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        backGround(g2);
        Ship.getInstance(this).paint(g2);
        for (List<Alien> arr : inimigos) {
            for (Alien i : arr) {
                i.paint(g2);
            }

        }

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Space Invaders");
        Universe painel = new Universe();

        label = new JLabel();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(800, 600));
        frame.addKeyListener(Ship.getInstance(painel));
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
        frame.add(painel);

        label.setBounds(400, 10, 10, 10);

        painel.add(label);
        label.setVisible(true);
        label.setForeground(Color.WHITE);

        Thread t = new Thread(painel);
        t.start();

    }

    public void update() {
        Ship.getInstance(this).update();
        contador++;
    }

    @Override
    public void run() {
        boolean l = true;
        while (true) {
            update();
            repaint();

            for (List<Alien> arr : inimigos) {
                for (Alien i : arr) {
                    i.colidir(ship.tiro);
                    i.update();
                    if (i.bateParede()) {

                        l = true;
                    }

                    if (i.y >= Ship.getInstance(this).y - 40) {
                        JOptionPane.showMessageDialog(singleton, "Missão fracassada :( ");
                        System.exit(0);

                    }
                    if (cont == 4000) {
                        JOptionPane.showMessageDialog(singleton, "Missão cumprida :) ");
                        System.exit(0);
                    }
                }

            }

            for (List<Alien> arr : inimigos) {
                for (Alien i : arr) {
                    if (l) {
                        i.pulay();

                        i.inverte();

                    }
                }
            }

            l = false;
            if (contador % 200 == 0) {

                int linha = (int) (Math.random() * (4 - 0 + 1)) + 0;
                int coluna = (int) (Math.random() * (10 - 0 + 1)) + 0;

                while (linha > inimigos.size() - 1 || inimigos.get(linha).size() == 0) {
                    linha = (int) (Math.random() * (4 - 0 + 1)) + 0;

                }
                while (coluna > inimigos.get(linha).size() - 1) {
                    coluna = (int) (Math.random() * (10 - 0 + 1)) + 0;

                }
                inimigos.get(linha).get(coluna).vely = 2;
                inimigos.get(linha).get(coluna).velx = 3;

            }

            for (int i = 0; i < inimigos.size(); i++) {
                inimigos.get(i).removeIf(m -> !m.alive);

            }
            label.setText("SCORE: " + cont);

            try {
                Thread.sleep(35);
            } catch (InterruptedException ex) {

            }
        }

    }

}
