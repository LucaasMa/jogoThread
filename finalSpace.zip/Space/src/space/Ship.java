package space;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Ship extends Element implements KeyListener {

    static double _x = 350;
    static double _y = 500;
    static int _w = 50;
    static int _h = 58;
    static int vel = 8;
    public Missile tiro;
    public boolean shooting;
    public static Ship singleton;
    private Universe universe;

    public static Ship getInstance(Universe universe) {
        if (singleton == null) {
            singleton
                    = new Ship(universe);

        }
        return singleton;

    }

    private Ship(Universe universe) {
        super(_x, _y, _w, _h, 0, 0);
        this.universe = universe;
        this.caminho = "src/space/imagens/nave.png";
        super.image();
    }

    public void shoot() {
        if (tiro == null || !tiro.vivo) {
            tiro = new Missile(x + _w / 2 - Missile.w_ / 2, y);

        }

    }

    @Override
    public void move() {
        this.x += this.velx;
        if (this.x <= 0 || this.x >= 770 - _w / 2) {
            this.x -= this.velx;
        }
    }

    @Override
    public void update() {

        super.update();
        if (shooting) {
            this.shoot();
        }
        if (tiro != null) {

            universe.getInimigos();

            tiro.update();
        }
    }

    @Override
    public void paint(Graphics2D g2) {
        super.paint(g2);
        if (tiro != null && tiro.vivo) {
            tiro.paint(g2);

        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT) {
            this.velx = vel;

        } else if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT) {
            this.velx = -vel;

        }
        if (key == KeyEvent.VK_SPACE) {
            this.shooting = true;
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT) {
            this.velx = 0;

        } else if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT) {
            this.velx = 0;

        }
        if (key == KeyEvent.VK_SPACE) {
            this.shooting = false;
        }
    }

}
